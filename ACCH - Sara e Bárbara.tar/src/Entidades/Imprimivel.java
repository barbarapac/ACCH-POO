package Entidades;

public interface Imprimivel {

    ContaBancaria mostrarDados(int parmNumconta);
}
